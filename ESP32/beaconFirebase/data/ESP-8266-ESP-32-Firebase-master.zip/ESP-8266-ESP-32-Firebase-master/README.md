# ESP-8266-ESP-32-Firebase
This repository contains a Firebase API for ESP8266 and ESP32 based devices.
